# Como Executar no Xeno

## Passos para Executar

1. **Abra o Xeno Executor**
   - Certifique-se de que o Xeno está instalado e funcionando
   - Abra o Roblox e entre em um jogo

2. **Copie o Código**
   - Abra o arquivo `Example.lua` neste projeto
   - Copie todo o conteúdo do arquivo (Ctrl+A, Ctrl+C)

3. **Cole no Xeno**
   - Abra o Xeno executor
   - Cole o código na área de script
   - Clique em "Execute" ou pressione o atalho de execução

4. **Pronto!**
   - A interface Obsidian UI será carregada automaticamente
   - O menu aparecerá no jogo
   - Use a tecla padrão (RightShift) para abrir/fechar o menu

## Notas Importantes

- O script carrega automaticamente a biblioteca do GitHub
- Certifique-se de ter conexão com a internet para baixar os arquivos necessários
- Se houver problemas, verifique se o Xeno tem permissão para fazer requisições HTTP

## Personalização

Você pode modificar o arquivo `Example.lua` antes de executar para:
- Alterar o título da janela
- Modificar as configurações padrão
- Adicionar seus próprios elementos de UI

## Alternativa: Usar Arquivos Locais

Se preferir usar os arquivos locais ao invés de baixar do GitHub, você precisará:
1. Carregar o `Library.lua` localmente
2. Ajustar o código para não usar `game:HttpGet()`

